package com.projectbible.shop.maven.jpa.postgresql.auth.presentation;

import com.projectbible.shop.maven.jpa.postgresql.auth.application.AuthService;
import com.projectbible.shop.maven.jpa.postgresql.common.api.ApiResponse;
import com.projectbible.shop.maven.jpa.postgresql.common.security.AuthContext;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Map;
import org.springframework.web.bind.annotation.*;

@Tag(name = "auth")
@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {
    private final AuthService service;

    public AuthController(AuthService service) {
        this.service = service;
    }

    @Operation(summary = "User signup")
    @PostMapping("/signup")
    public ApiResponse<Map<String, Object>> signup(@RequestBody Map<String, Object> body) {
        return ApiResponse.success(service.signup(body));
    }

    @Operation(summary = "User login")
    @PostMapping("/login")
    public ApiResponse<Map<String, Object>> login(@RequestBody Map<String, Object> body) {
        return ApiResponse.success(service.login(body));
    }

    @Operation(summary = "User refresh")
    @PostMapping("/refresh")
    public ApiResponse<Map<String, Object>> refresh(@RequestBody Map<String, Object> body) {
        return ApiResponse.success(service.refresh(body));
    }

    @Operation(summary = "User logout")
    @PostMapping("/logout")
    public ApiResponse<Map<String, Object>> logout(HttpServletRequest request) {
        return ApiResponse.success(service.logout(AuthContext.requireUser(request)));
    }
}
