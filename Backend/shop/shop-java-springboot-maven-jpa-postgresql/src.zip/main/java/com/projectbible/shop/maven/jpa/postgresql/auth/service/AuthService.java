package com.projectbible.shop.maven.jpa.postgresql.auth.application;

import com.projectbible.shop.maven.jpa.postgresql.common.exception.AppException;
import com.projectbible.shop.maven.jpa.postgresql.common.security.CurrentActor;
import com.projectbible.shop.maven.jpa.postgresql.common.security.TokenService;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.HexFormat;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    private final JdbcTemplate jdbcTemplate;
    private final TokenService tokenService;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public AuthService(JdbcTemplate jdbcTemplate, TokenService tokenService) {
        this.jdbcTemplate = jdbcTemplate;
        this.tokenService = tokenService;
    }

    public Map<String, Object> signup(Map<String, Object> body) {
        String email = required(body, "email").toLowerCase();
        String password = required(body, "password");
        String name = required(body, "name");
        String phone = required(body, "phone");
        Integer count = jdbcTemplate.queryForObject("select count(*) from users where email = ?", Integer.class, email);
        if (count != null && count > 0) {
            throw new AppException("DUPLICATE_EMAIL", "Email already exists", HttpStatus.CONFLICT);
        }
        Long id = jdbcTemplate.queryForObject(
            "insert into users (email, password_hash, name, phone, status) values (?, ?, ?, ?, 'ACTIVE') returning id",
            Long.class,
            email, encoder.encode(password), name, phone
        );
        return jdbcTemplate.queryForMap("select id, email, name, phone, status, created_at as \"createdAt\" from users where id = ?", id);
    }

    public Map<String, Object> login(Map<String, Object> body) {
        String email = required(body, "email").toLowerCase();
        String password = required(body, "password");
        var rows = jdbcTemplate.queryForList("select id, email, password_hash as \"passwordHash\", name, phone, status, created_at as \"createdAt\" from users where email = ? and deleted_at is null", email);
        if (rows.isEmpty() || !encoder.matches(password, String.valueOf(rows.get(0).get("passwordHash")))) {
            throw new AppException("INVALID_CREDENTIALS", "Invalid credentials", HttpStatus.UNAUTHORIZED);
        }
        Map<String, Object> user = rows.get(0);
        CurrentActor actor = new CurrentActor(Long.valueOf(String.valueOf(user.get("id"))), String.valueOf(user.get("email")), "USER", "user");
        Map<String, Object> tokens = issueUserTokens(actor);
        return Map.of(
            "accessToken", tokens.get("accessToken"),
            "refreshToken", tokens.get("refreshToken"),
            "expiresIn", tokens.get("expiresIn"),
            "user", Map.of("id", user.get("id"), "email", user.get("email"), "name", user.get("name"), "phone", user.get("phone"), "status", user.get("status"), "createdAt", user.get("createdAt"))
        );
    }

    public Map<String, Object> refresh(Map<String, Object> body) {
        String refreshToken = required(body, "refreshToken");
        var rows = jdbcTemplate.queryForList(
            "select urt.id, urt.user_id as \"userId\", u.email from user_refresh_tokens urt join users u on u.id = urt.user_id where urt.token_key = ? and urt.revoked = false and urt.expires_at > now() and u.deleted_at is null",
            hash(refreshToken)
        );
        if (rows.isEmpty()) {
            throw new AppException("UNAUTHORIZED", "Invalid refresh token", HttpStatus.UNAUTHORIZED);
        }
        Map<String, Object> row = rows.get(0);
        jdbcTemplate.update("update user_refresh_tokens set revoked = true, updated_at = now() where id = ?", row.get("id"));
        return issueUserTokens(new CurrentActor(Long.valueOf(String.valueOf(row.get("userId"))), String.valueOf(row.get("email")), "USER", "user"));
    }

    public Map<String, Object> logout(CurrentActor actor) {
        if (!actor.isUser()) {
            throw new AppException("FORBIDDEN", "User access required", HttpStatus.FORBIDDEN);
        }
        jdbcTemplate.update("update user_refresh_tokens set revoked = true, updated_at = now() where user_id = ? and revoked = false", actor.id());
        return Map.of("message", "Logged out successfully");
    }

    private Map<String, Object> issueUserTokens(CurrentActor actor) {
        String accessToken = tokenService.createAccessToken(actor, 1800);
        String refreshToken = UUID.randomUUID().toString();
        jdbcTemplate.update(
            "insert into user_refresh_tokens (user_id, token_key, expires_at, revoked) values (?, ?, ?, false)",
            actor.id(), hash(refreshToken), Timestamp.from(Instant.now().plusSeconds(7 * 24 * 3600L))
        );
        return Map.of("accessToken", accessToken, "refreshToken", refreshToken, "expiresIn", 1800);
    }

    private String required(Map<String, Object> body, String key) {
        Object value = body.get(key);
        if (value == null || String.valueOf(value).trim().isEmpty()) {
            throw new AppException("VALIDATION_ERROR", key + " is required", HttpStatus.BAD_REQUEST);
        }
        return String.valueOf(value).trim();
    }

    private String hash(String value) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
