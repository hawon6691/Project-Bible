package com.projectbible.shop.maven.jpa.postgresql.user.presentation;

import com.projectbible.shop.maven.jpa.postgresql.common.api.ApiResponse;
import com.projectbible.shop.maven.jpa.postgresql.common.security.AuthContext;
import com.projectbible.shop.maven.jpa.postgresql.user.application.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Map;
import org.springframework.web.bind.annotation.*;

@Tag(name = "users")
@RestController
@RequestMapping("/api/v1/users")
public class UserController {
    private final UserService service;

    public UserController(UserService service) {
        this.service = service;
    }

    @Operation(summary = "Current user")
    @GetMapping("/me")
    public ApiResponse<Map<String, Object>> me(HttpServletRequest request) {
        return ApiResponse.success(service.me(AuthContext.requireUser(request)));
    }

    @Operation(summary = "Update current user")
    @PatchMapping("/me")
    public ApiResponse<Map<String, Object>> update(HttpServletRequest request, @RequestBody Map<String, Object> body) {
        return ApiResponse.success(service.update(AuthContext.requireUser(request), body));
    }

    @Operation(summary = "Delete current user")
    @DeleteMapping("/me")
    public ApiResponse<Map<String, Object>> remove(HttpServletRequest request) {
        return ApiResponse.success(service.remove(AuthContext.requireUser(request)));
    }
}
