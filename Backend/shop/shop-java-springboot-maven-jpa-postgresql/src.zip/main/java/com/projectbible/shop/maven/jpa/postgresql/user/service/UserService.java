package com.projectbible.shop.maven.jpa.postgresql.user.application;

import com.projectbible.shop.maven.jpa.postgresql.common.exception.AppException;
import com.projectbible.shop.maven.jpa.postgresql.common.security.CurrentActor;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    private final JdbcTemplate jdbcTemplate;

    public UserService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Map<String, Object> me(CurrentActor actor) {
        requireUser(actor);
        var rows = jdbcTemplate.queryForList("select id, email, name, phone, status, created_at as \"createdAt\", updated_at as \"updatedAt\" from users where id = ? and deleted_at is null", actor.id());
        if (rows.isEmpty()) {
            throw new AppException("USER_NOT_FOUND", "User not found", HttpStatus.NOT_FOUND);
        }
        return rows.get(0);
    }

    public Map<String, Object> update(CurrentActor actor, Map<String, Object> body) {
        requireUser(actor);
        Map<String, Object> current = me(actor);
        String name = body.get("name") != null && !String.valueOf(body.get("name")).trim().isEmpty() ? String.valueOf(body.get("name")).trim() : String.valueOf(current.get("name"));
        String phone = body.get("phone") != null && !String.valueOf(body.get("phone")).trim().isEmpty() ? String.valueOf(body.get("phone")).trim() : String.valueOf(current.get("phone"));
        jdbcTemplate.update("update users set name = ?, phone = ?, updated_at = now() where id = ?", name, phone, actor.id());
        return me(actor);
    }

    public Map<String, Object> remove(CurrentActor actor) {
        requireUser(actor);
        jdbcTemplate.update("update users set status = 'DELETED', deleted_at = now(), updated_at = now() where id = ?", actor.id());
        jdbcTemplate.update("update user_refresh_tokens set revoked = true, updated_at = now() where user_id = ?", actor.id());
        return Map.of("message", "User deleted successfully");
    }

    private void requireUser(CurrentActor actor) {
        if (!actor.isUser()) {
            throw new AppException("FORBIDDEN", "User access required", HttpStatus.FORBIDDEN);
        }
    }
}
