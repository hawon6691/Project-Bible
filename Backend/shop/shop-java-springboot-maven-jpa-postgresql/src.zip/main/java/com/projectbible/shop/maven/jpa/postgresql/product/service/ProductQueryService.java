package com.projectbible.shop.maven.jpa.postgresql.product.application;

import com.projectbible.shop.maven.jpa.postgresql.common.exception.AppException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class ProductQueryService {
    private final JdbcTemplate jdbcTemplate;

    public ProductQueryService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Map<String, Object> list(Map<String, String> query) {
        int page = page(query.get("page"));
        int limit = limit(query.get("limit"));
        int offset = (page - 1) * limit;
        List<Object> params = new ArrayList<>();
        List<String> filters = new ArrayList<>(List.of("p.status <> 'DELETED'", "p.status = 'ACTIVE'"));
        if (query.get("categoryId") != null && !query.get("categoryId").isBlank()) {
            params.add(Long.valueOf(query.get("categoryId")));
            filters.add("p.category_id = ?");
        }
        if (query.get("search") != null && !query.get("search").isBlank()) {
            String pattern = "%" + query.get("search").trim() + "%";
            params.add(pattern);
            params.add(pattern);
            filters.add("(p.name ilike ? or coalesce(p.description,'') ilike ?)");
        }
        if (query.get("status") != null && !query.get("status").isBlank()) {
            filters.remove("p.status = 'ACTIVE'");
            params.add(query.get("status").trim().toUpperCase());
            filters.add("p.status = ?");
        }
        String where = " where " + String.join(" and ", filters);
        Integer totalCount = jdbcTemplate.queryForObject("select count(*) from products p" + where, Integer.class, params.toArray());
        List<Object> listParams = new ArrayList<>(params);
        listParams.add(limit);
        listParams.add(offset);
        List<Map<String, Object>> items = jdbcTemplate.queryForList(
            """
            select p.id,
                   p.category_id as "categoryId",
                   p.name,
                   p.price,
                   p.stock,
                   p.status,
                   (
                     select pi.image_url
                     from product_images pi
                     where pi.product_id = p.id
                     order by pi.is_primary desc, pi.display_order asc, pi.id asc
                     limit 1
                   ) as "thumbnailUrl"
            from products p
            """ + where + """
            order by """ + sort(query.get("sort")) + """
            limit ? offset ?
            """,
            listParams.toArray()
        );
        return Map.of("items", items, "meta", meta(page, limit, totalCount == null ? 0 : totalCount));
    }

    public Map<String, Object> one(long productId) {
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(
            """
            select p.id, p.category_id as "categoryId", p.name, p.description, p.price, p.stock, p.status,
                   p.created_at as "createdAt", p.updated_at as "updatedAt"
            from products p
            where p.id = ? and p.status <> 'DELETED'
            """,
            productId
        );
        if (rows.isEmpty()) {
            throw new AppException("PRODUCT_NOT_FOUND", "Product not found", HttpStatus.NOT_FOUND);
        }
        Map<String, Object> product = rows.get(0);
        List<Map<String, Object>> options = jdbcTemplate.queryForList(
            """
            select id, product_id as "productId", name, value, additional_price as "additionalPrice", stock,
                   created_at as "createdAt", updated_at as "updatedAt"
            from product_options
            where product_id = ?
            order by id asc
            """,
            productId
        );
        List<Map<String, Object>> images = jdbcTemplate.queryForList(
            """
            select id, product_id as "productId", image_url as "imageUrl", is_primary as "isPrimary", display_order as "displayOrder",
                   created_at as "createdAt", updated_at as "updatedAt"
            from product_images
            where product_id = ?
            order by display_order asc, id asc
            """,
            productId
        );
        product.put("options", options);
        product.put("images", images);
        return product;
    }

    public Map<String, Object> create(Map<String, Object> body) {
        long categoryId = number(body.get("categoryId"), "categoryId");
        ensureCategory(categoryId);
        Long id = jdbcTemplate.queryForObject(
            """
            insert into products (category_id, name, description, price, stock, status)
            values (?, ?, ?, ?, ?, ?)
            returning id
            """,
            Long.class,
            categoryId,
            required(body, "name"),
            body.get("description") == null ? null : String.valueOf(body.get("description")).trim(),
            number(body.get("price"), "price"),
            number(body.get("stock"), "stock"),
            body.get("status") == null || String.valueOf(body.get("status")).isBlank() ? "ACTIVE" : String.valueOf(body.get("status")).trim().toUpperCase()
        );
        return one(id == null ? -1 : id);
    }

    public Map<String, Object> update(long productId, Map<String, Object> body) {
        Map<String, Object> current = one(productId);
        long categoryId = body.containsKey("categoryId") ? number(body.get("categoryId"), "categoryId") : ((Number) current.get("categoryId")).longValue();
        ensureCategory(categoryId);
        jdbcTemplate.update(
            """
            update products
            set category_id = ?, name = ?, description = ?, price = ?, stock = ?, status = ?, updated_at = now()
            where id = ?
            """,
            categoryId,
            body.get("name") != null && !String.valueOf(body.get("name")).trim().isEmpty() ? String.valueOf(body.get("name")).trim() : String.valueOf(current.get("name")),
            body.containsKey("description") ? (body.get("description") == null ? null : String.valueOf(body.get("description")).trim()) : current.get("description"),
            body.containsKey("price") ? number(body.get("price"), "price") : ((Number) current.get("price")).intValue(),
            body.containsKey("stock") ? number(body.get("stock"), "stock") : ((Number) current.get("stock")).intValue(),
            body.get("status") != null && !String.valueOf(body.get("status")).trim().isEmpty() ? String.valueOf(body.get("status")).trim().toUpperCase() : String.valueOf(current.get("status")),
            productId
        );
        return one(productId);
    }

    public Map<String, Object> remove(long productId) {
        one(productId);
        jdbcTemplate.update("update products set status = 'DELETED', deleted_at = now(), updated_at = now() where id = ?", productId);
        return Map.of("message", "Product deleted successfully");
    }

    public Map<String, Object> createOption(long productId, Map<String, Object> body) {
        one(productId);
        return jdbcTemplate.queryForMap(
            """
            insert into product_options (product_id, name, value, additional_price, stock)
            values (?, ?, ?, ?, ?)
            returning id, product_id as "productId", name, value, additional_price as "additionalPrice", stock,
                     created_at as "createdAt", updated_at as "updatedAt"
            """,
            productId,
            required(body, "name"),
            required(body, "value"),
            number(body.getOrDefault("additionalPrice", 0), "additionalPrice"),
            number(body.get("stock"), "stock")
        );
    }

    public Map<String, Object> updateOption(long optionId, Map<String, Object> body) {
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(
            "select id, product_id as \"productId\", name, value, additional_price as \"additionalPrice\", stock from product_options where id = ?",
            optionId
        );
        if (rows.isEmpty()) {
            throw new AppException("PRODUCT_OPTION_NOT_FOUND", "Product option not found", HttpStatus.NOT_FOUND);
        }
        Map<String, Object> current = rows.get(0);
        return jdbcTemplate.queryForMap(
            """
            update product_options
            set name = ?, value = ?, additional_price = ?, stock = ?, updated_at = now()
            where id = ?
            returning id, product_id as "productId", name, value, additional_price as "additionalPrice", stock,
                     created_at as "createdAt", updated_at as "updatedAt"
            """,
            body.get("name") != null && !String.valueOf(body.get("name")).trim().isEmpty() ? String.valueOf(body.get("name")).trim() : String.valueOf(current.get("name")),
            body.get("value") != null && !String.valueOf(body.get("value")).trim().isEmpty() ? String.valueOf(body.get("value")).trim() : String.valueOf(current.get("value")),
            body.containsKey("additionalPrice") ? number(body.get("additionalPrice"), "additionalPrice") : ((Number) current.get("additionalPrice")).intValue(),
            body.containsKey("stock") ? number(body.get("stock"), "stock") : ((Number) current.get("stock")).intValue(),
            optionId
        );
    }

    public Map<String, Object> removeOption(long optionId) {
        int deleted = jdbcTemplate.update("delete from product_options where id = ?", optionId);
        if (deleted == 0) {
            throw new AppException("PRODUCT_OPTION_NOT_FOUND", "Product option not found", HttpStatus.NOT_FOUND);
        }
        return Map.of("message", "Product option deleted successfully");
    }

    public Map<String, Object> createImage(long productId, Map<String, Object> body) {
        one(productId);
        return jdbcTemplate.queryForMap(
            """
            insert into product_images (product_id, image_url, is_primary, display_order)
            values (?, ?, ?, ?)
            returning id, product_id as "productId", image_url as "imageUrl", is_primary as "isPrimary", display_order as "displayOrder",
                     created_at as "createdAt", updated_at as "updatedAt"
            """,
            productId,
            required(body, "imageUrl"),
            Boolean.parseBoolean(String.valueOf(body.getOrDefault("isPrimary", false))),
            number(body.getOrDefault("displayOrder", 0), "displayOrder")
        );
    }

    public Map<String, Object> updateImage(long imageId, Map<String, Object> body) {
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(
            "select id, product_id as \"productId\", image_url as \"imageUrl\", is_primary as \"isPrimary\", display_order as \"displayOrder\" from product_images where id = ?",
            imageId
        );
        if (rows.isEmpty()) {
            throw new AppException("PRODUCT_NOT_FOUND", "Product image not found", HttpStatus.NOT_FOUND);
        }
        Map<String, Object> current = rows.get(0);
        return jdbcTemplate.queryForMap(
            """
            update product_images
            set image_url = ?, is_primary = ?, display_order = ?, updated_at = now()
            where id = ?
            returning id, product_id as "productId", image_url as "imageUrl", is_primary as "isPrimary", display_order as "displayOrder",
                     created_at as "createdAt", updated_at as "updatedAt"
            """,
            body.get("imageUrl") != null && !String.valueOf(body.get("imageUrl")).trim().isEmpty() ? String.valueOf(body.get("imageUrl")).trim() : String.valueOf(current.get("imageUrl")),
            body.containsKey("isPrimary") ? Boolean.parseBoolean(String.valueOf(body.get("isPrimary"))) : Boolean.parseBoolean(String.valueOf(current.get("isPrimary"))),
            body.containsKey("displayOrder") ? number(body.get("displayOrder"), "displayOrder") : ((Number) current.get("displayOrder")).intValue(),
            imageId
        );
    }

    public Map<String, Object> removeImage(long imageId) {
        int deleted = jdbcTemplate.update("delete from product_images where id = ?", imageId);
        if (deleted == 0) {
            throw new AppException("PRODUCT_NOT_FOUND", "Product image not found", HttpStatus.NOT_FOUND);
        }
        return Map.of("message", "Product image deleted successfully");
    }

    private void ensureCategory(long categoryId) {
        Integer count = jdbcTemplate.queryForObject("select count(*) from categories where id = ? and status <> 'DELETED'", Integer.class, categoryId);
        if (count == null || count == 0) {
            throw new AppException("CATEGORY_NOT_FOUND", "Category not found", HttpStatus.NOT_FOUND);
        }
    }

    private String required(Map<String, Object> body, String key) {
        Object value = body.get(key);
        if (value == null || String.valueOf(value).trim().isEmpty()) {
            throw new AppException("VALIDATION_ERROR", key + " is required", HttpStatus.BAD_REQUEST);
        }
        return String.valueOf(value).trim();
    }

    private int number(Object value, String key) {
        try {
            return Integer.parseInt(String.valueOf(value));
        } catch (Exception ex) {
            throw new AppException("VALIDATION_ERROR", key + " must be a number", HttpStatus.BAD_REQUEST);
        }
    }

    private int page(String value) {
        return value == null || value.isBlank() ? 1 : Math.max(Integer.parseInt(value), 1);
    }

    private int limit(String value) {
        return value == null || value.isBlank() ? 20 : Math.max(Integer.parseInt(value), 1);
    }

    private Map<String, Object> meta(int page, int limit, int totalCount) {
        int totalPages = (int) Math.ceil(totalCount / (double) limit);
        return Map.of("page", page, "limit", limit, "totalCount", totalCount, "totalPages", totalPages);
    }

    private String sort(String value) {
        if (value == null) return "p.created_at desc, p.id desc";
        return switch (value.toLowerCase()) {
            case "price_asc" -> "p.price asc, p.id desc";
            case "price_desc" -> "p.price desc, p.id desc";
            case "popular" -> "p.stock desc, p.id desc";
            default -> "p.created_at desc, p.id desc";
        };
    }
}
