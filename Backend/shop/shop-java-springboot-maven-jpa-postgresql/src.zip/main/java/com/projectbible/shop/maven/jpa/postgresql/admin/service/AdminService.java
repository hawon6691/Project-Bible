package com.projectbible.shop.maven.jpa.postgresql.admin.application;

import com.projectbible.shop.maven.jpa.postgresql.common.exception.AppException;
import com.projectbible.shop.maven.jpa.postgresql.common.security.CurrentActor;
import com.projectbible.shop.maven.jpa.postgresql.common.security.TokenService;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.HexFormat;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AdminService {
    private final JdbcTemplate jdbcTemplate;
    private final TokenService tokenService;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public AdminService(JdbcTemplate jdbcTemplate, TokenService tokenService) {
        this.jdbcTemplate = jdbcTemplate;
        this.tokenService = tokenService;
    }

    public Map<String, Object> login(Map<String, Object> body) {
        String email = required(body, "email").toLowerCase();
        String password = required(body, "password");
        var rows = jdbcTemplate.queryForList("select id, email, password_hash as \"passwordHash\", name, status, created_at as \"createdAt\" from admins where email = ?", email);
        if (rows.isEmpty() || !encoder.matches(password, String.valueOf(rows.get(0).get("passwordHash")))) {
            throw new AppException("INVALID_CREDENTIALS", "Invalid credentials", HttpStatus.UNAUTHORIZED);
        }
        Map<String, Object> admin = rows.get(0);
        CurrentActor actor = new CurrentActor(Long.valueOf(String.valueOf(admin.get("id"))), String.valueOf(admin.get("email")), "ADMIN", "admin");
        Map<String, Object> tokens = issueAdminTokens(actor);
        return Map.of(
            "accessToken", tokens.get("accessToken"),
            "refreshToken", tokens.get("refreshToken"),
            "expiresIn", tokens.get("expiresIn"),
            "admin", Map.of("id", admin.get("id"), "email", admin.get("email"), "name", admin.get("name"), "status", admin.get("status"), "createdAt", admin.get("createdAt"))
        );
    }

    public Map<String, Object> refresh(Map<String, Object> body) {
        String refreshToken = required(body, "refreshToken");
        var rows = jdbcTemplate.queryForList(
            "select art.id, art.admin_id as \"adminId\", a.email from admin_refresh_tokens art join admins a on a.id = art.admin_id where art.token_key = ? and art.revoked = false and art.expires_at > now()",
            hash(refreshToken)
        );
        if (rows.isEmpty()) {
            throw new AppException("UNAUTHORIZED", "Invalid refresh token", HttpStatus.UNAUTHORIZED);
        }
        Map<String, Object> row = rows.get(0);
        jdbcTemplate.update("update admin_refresh_tokens set revoked = true, updated_at = now() where id = ?", row.get("id"));
        return issueAdminTokens(new CurrentActor(Long.valueOf(String.valueOf(row.get("adminId"))), String.valueOf(row.get("email")), "ADMIN", "admin"));
    }

    public Map<String, Object> logout(CurrentActor actor) {
        requireAdmin(actor);
        jdbcTemplate.update("update admin_refresh_tokens set revoked = true, updated_at = now() where admin_id = ? and revoked = false", actor.id());
        return Map.of("message", "Admin logged out successfully");
    }

    public Map<String, Object> me(CurrentActor actor) {
        requireAdmin(actor);
        var rows = jdbcTemplate.queryForList("select id, email, name, status, created_at as \"createdAt\" from admins where id = ?", actor.id());
        if (rows.isEmpty()) {
            throw new AppException("ADMIN_NOT_FOUND", "Admin not found", HttpStatus.NOT_FOUND);
        }
        return rows.get(0);
    }

    public Map<String, Object> dashboard() {
        return Map.of(
            "orderSummary", Map.of(
                "pending", scalar("select count(*) from orders where order_status = 'PENDING'"),
                "paid", scalar("select count(*) from orders where order_status = 'PAID'"),
                "shipping", scalar("select count(*) from orders where order_status = 'SHIPPING'"),
                "cancelled", scalar("select count(*) from orders where order_status = 'CANCELLED'")
            ),
            "productSummary", Map.of(
                "active", scalar("select count(*) from products where status = 'ACTIVE'"),
                "hidden", scalar("select count(*) from products where status = 'HIDDEN'"),
                "deleted", scalar("select count(*) from products where status = 'DELETED'")
            ),
            "userSummary", Map.of(
                "active", scalar("select count(*) from users where status = 'ACTIVE' and deleted_at is null"),
                "newUsersToday", scalar("select count(*) from users where created_at::date = current_date and deleted_at is null")
            ),
            "reviewSummary", Map.of(
                "active", scalar("select count(*) from reviews where status = 'ACTIVE' and deleted_at is null"),
                "hidden", scalar("select count(*) from reviews where status = 'HIDDEN' and deleted_at is null"),
                "deleted", scalar("select count(*) from reviews where status = 'DELETED'")
            )
        );
    }

    private Map<String, Object> issueAdminTokens(CurrentActor actor) {
        String accessToken = tokenService.createAccessToken(actor, 1800);
        String refreshToken = UUID.randomUUID().toString();
        jdbcTemplate.update(
            "insert into admin_refresh_tokens (admin_id, token_key, expires_at, revoked) values (?, ?, ?, false)",
            actor.id(), hash(refreshToken), Timestamp.from(Instant.now().plusSeconds(7 * 24 * 3600L))
        );
        return Map.of("accessToken", accessToken, "refreshToken", refreshToken, "expiresIn", 1800);
    }

    private int scalar(String sql) {
        Integer value = jdbcTemplate.queryForObject(sql, Integer.class);
        return value == null ? 0 : value;
    }

    private void requireAdmin(CurrentActor actor) {
        if (!actor.isAdmin()) {
            throw new AppException("FORBIDDEN", "Admin access required", HttpStatus.FORBIDDEN);
        }
    }

    private String required(Map<String, Object> body, String key) {
        Object value = body.get(key);
        if (value == null || String.valueOf(value).trim().isEmpty()) {
            throw new AppException("VALIDATION_ERROR", key + " is required", HttpStatus.BAD_REQUEST);
        }
        return String.valueOf(value).trim();
    }

    private String hash(String value) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
