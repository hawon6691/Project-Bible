package com.projectbible.shop.maven.jpa.postgresql.category.application;

import com.projectbible.shop.maven.jpa.postgresql.common.exception.AppException;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class CategoryQueryService {
    private final JdbcTemplate jdbcTemplate;

    public CategoryQueryService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Map<String, Object>> list(String status) {
        if (status != null && !status.isBlank()) {
            return jdbcTemplate.queryForList(
                """
                select id, name, display_order as "displayOrder", status, created_at as "createdAt", updated_at as "updatedAt"
                from categories
                where status = ?
                order by display_order asc, id asc
                """,
                status.trim().toUpperCase()
            );
        }
        return jdbcTemplate.queryForList(
            """
            select id, name, display_order as "displayOrder", status, created_at as "createdAt", updated_at as "updatedAt"
            from categories
            where status <> 'DELETED'
            order by display_order asc, id asc
            """
        );
    }

    public Map<String, Object> one(long categoryId) {
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(
            """
            select id, name, display_order as "displayOrder", status, created_at as "createdAt", updated_at as "updatedAt"
            from categories
            where id = ?
            """,
            categoryId
        );
        if (rows.isEmpty()) {
            throw new AppException("CATEGORY_NOT_FOUND", "Category not found", HttpStatus.NOT_FOUND);
        }
        return rows.get(0);
    }

    public Map<String, Object> create(Map<String, Object> body) {
        return jdbcTemplate.queryForMap(
            """
            insert into categories (name, display_order, status)
            values (?, ?, 'ACTIVE')
            returning id, name, display_order as "displayOrder", status, created_at as "createdAt", updated_at as "updatedAt"
            """,
            required(body, "name"), number(body.getOrDefault("displayOrder", 0), "displayOrder")
        );
    }

    public Map<String, Object> update(long categoryId, Map<String, Object> body) {
        Map<String, Object> current = one(categoryId);
        String name = body.get("name") != null && !String.valueOf(body.get("name")).trim().isEmpty() ? String.valueOf(body.get("name")).trim() : String.valueOf(current.get("name"));
        int displayOrder = body.containsKey("displayOrder") ? number(body.get("displayOrder"), "displayOrder") : ((Number) current.get("displayOrder")).intValue();
        String status = body.get("status") != null && !String.valueOf(body.get("status")).trim().isEmpty() ? String.valueOf(body.get("status")).trim().toUpperCase() : String.valueOf(current.get("status"));
        return jdbcTemplate.queryForMap(
            """
            update categories
            set name = ?, display_order = ?, status = ?, updated_at = now()
            where id = ?
            returning id, name, display_order as "displayOrder", status, created_at as "createdAt", updated_at as "updatedAt"
            """,
            name, displayOrder, status, categoryId
        );
    }

    public Map<String, Object> remove(long categoryId) {
        one(categoryId);
        jdbcTemplate.update("update categories set status = 'DELETED', updated_at = now() where id = ?", categoryId);
        return Map.of("message", "Category deleted successfully");
    }

    private String required(Map<String, Object> body, String key) {
        Object value = body.get(key);
        if (value == null || String.valueOf(value).trim().isEmpty()) {
            throw new AppException("VALIDATION_ERROR", key + " is required", HttpStatus.BAD_REQUEST);
        }
        return String.valueOf(value).trim();
    }

    private int number(Object value, String key) {
        try {
            return Integer.parseInt(String.valueOf(value));
        } catch (Exception ex) {
            throw new AppException("VALIDATION_ERROR", key + " must be a number", HttpStatus.BAD_REQUEST);
        }
    }
}
