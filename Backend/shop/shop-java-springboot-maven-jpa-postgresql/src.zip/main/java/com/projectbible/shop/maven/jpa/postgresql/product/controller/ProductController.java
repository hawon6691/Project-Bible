package com.projectbible.shop.maven.jpa.postgresql.product.presentation;

import com.projectbible.shop.maven.jpa.postgresql.common.api.ApiResponse;
import com.projectbible.shop.maven.jpa.postgresql.product.application.ProductQueryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.Map;
import org.springframework.web.bind.annotation.*;

@Tag(name = "products")
@RestController
@RequestMapping("/api/v1/products")
public class ProductController {
    private final ProductQueryService service;

    public ProductController(ProductQueryService service) {
        this.service = service;
    }

    @Operation(summary = "List products")
    @GetMapping
    public ApiResponse<Object> list(@RequestParam Map<String, String> query) {
        Map<String, Object> result = service.list(query);
        return ApiResponse.success(result.get("items"), result.get("meta"));
    }

    @Operation(summary = "Get product detail")
    @GetMapping("/{productId}")
    public ApiResponse<Map<String, Object>> one(@PathVariable long productId) {
        return ApiResponse.success(service.one(productId));
    }
}
